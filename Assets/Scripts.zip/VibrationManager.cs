using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VibrationManager
{
    public void TriggerVibration(int iteration, int frecuency, int strength)
    {
        OVRHapticsClip clip = new OVRHapticsClip(iteration);

        for(int i = 0; i < iteration; i++)
        {
            clip.Samples[i] = (i % frecuency == 0 ? (byte)0 : (byte)strength);
        }
        clip = new OVRHapticsClip(clip.Samples, clip.Samples.Length);

        OVRHaptics.RightChannel.Preempt(clip);
    }
}
